This data is from:

Volpe, G., and Jameson, A., “Transonic Potential Flow Calculations
by Two Articial Density Methods,” AIAA Journal, Vol. 26, No. 4,
April 1988, pp. 425–429.
doi:10.2514/3.9910

and from

@inproceedings{Mason20067TA,
  title={7. Transonic Aerodynamics of Airfoils and Wings 7.1 Introduction},
  author={William H. Mason},
  year={2006}
}