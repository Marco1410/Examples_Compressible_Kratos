import numpy as np
import matplotlib.pyplot as plt

# #### CP PLOT NACA
# ######################################################################
# fig = plt.figure()
# fig.set_figwidth(15.0)
# fig.set_figheight(8.0)

# x_1  = np.loadtxt('flo36/cp_flo36_aoa_1_mach_72 (copia).dat', usecols=(0,))
# cp_1 = np.loadtxt('flo36/cp_flo36_aoa_1_mach_72 (copia).dat', usecols=(1,))
# fig = plt.plot(x_1, cp_1, "o", markersize = 5.0, label = '1')

# x_2  = np.loadtxt('flo36/cp_flo36_aoa_1_mach_73 (copia).dat', usecols=(0,))
# cp_2 = np.loadtxt('flo36/cp_flo36_aoa_1_mach_73 (copia).dat', usecols=(1,))
# fig = plt.plot(x_2, cp_2, "o", markersize = 5.0, label = '2')

# x_3  = np.loadtxt('flo36/cp_flo36_aoa_1_mach_75 (copia).dat', usecols=(0,))
# cp_3 = np.loadtxt('flo36/cp_flo36_aoa_1_mach_75 (copia).dat', usecols=(1,))
# fig = plt.plot(x_3, cp_3, "o", markersize = 5.0, label = '3')

# x_4  = np.loadtxt('flo36/cp_flo36_aoa_2_mach_75 (copia).dat', usecols=(0,))
# cp_4 = np.loadtxt('flo36/cp_flo36_aoa_2_mach_75 (copia).dat', usecols=(1,))
# fig = plt.plot(x_4, cp_4, "o", markersize = 5.0, label = '4')

# fig = plt.title('Cp vs x')
# fig = plt.ylabel('Cp')
# fig = plt.xlabel('x')
# fig = plt.grid()
# fig = plt.legend()
# fig = plt.gca().invert_yaxis()
# fig = plt.tight_layout()
# fig = plt.show()
# # fig = plt.savefig("reference_data_naca0012_flo36.png", dpi=400)
# fig = plt.close('all')


#### CP PLOT ONERA
######################################################################
fig = plt.figure()
fig.set_figwidth(15.0)
fig.set_figheight(8.0)

x_1  = np.loadtxt('onera/experiment/cp_20.dat', usecols=(0,))
cp_1 = np.loadtxt('onera/experiment/cp_20.dat', usecols=(1,))
fig = plt.plot(x_1, cp_1, "x-", markersize = 5.0, label = '20')

x_2  = np.loadtxt('onera/experiment/cp_44.dat', usecols=(0,))
cp_2 = np.loadtxt('onera/experiment/cp_44.dat', usecols=(1,))
fig = plt.plot(x_2, cp_2, "x-", markersize = 5.0, label = '44')

x_3  = np.loadtxt('onera/experiment/cp_65.dat', usecols=(0,))
cp_3 = np.loadtxt('onera/experiment/cp_65.dat', usecols=(1,))
fig = plt.plot(x_3, cp_3, "x-", markersize = 5.0, label = '65')

x_4  = np.loadtxt('onera/experiment/cp_80.dat', usecols=(0,))
cp_4 = np.loadtxt('onera/experiment/cp_80.dat', usecols=(1,))
fig = plt.plot(x_4, cp_4, "x-", markersize = 5.0, label = '80')

x_5  = np.loadtxt('onera/experiment/cp_90.dat', usecols=(0,))
cp_5 = np.loadtxt('onera/experiment/cp_90.dat', usecols=(1,))
fig = plt.plot(x_5, cp_5, "x-", markersize = 5.0, label = '90')

x_6  = np.loadtxt('onera/experiment/cp_95.dat', usecols=(0,))
cp_6 = np.loadtxt('onera/experiment/cp_95.dat', usecols=(1,))
fig = plt.plot(x_6, cp_6, "x-", markersize = 5.0, label = '95')

# x_7  = np.loadtxt('onera/experiment/cp_99.dat', usecols=(0,))
# cp_7 = np.loadtxt('onera/experiment/cp_99.dat', usecols=(1,))
# fig = plt.plot(x_7, cp_7, "x-", markersize = 5.0, label = '99')

fig = plt.title('Cp vs x')
fig = plt.ylabel('Cp')
fig = plt.xlabel('x')
fig = plt.grid()
fig = plt.legend()
# fig = plt.gca().invert_yaxis()
fig = plt.tight_layout()
fig = plt.show()
# fig = plt.savefig("reference_data_naca0012_flo36.png", dpi=400)
fig = plt.close('all')