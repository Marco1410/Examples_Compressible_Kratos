import matplotlib.pyplot as plt
import numpy as np
import os


labels = [95, 90, 80, 65, 44, 20] 

for idx in range(len(labels)):

    potential_skin_data_filename = f'cp_{labels[idx]}.dat'
    potential_skin_data_filename_new = f'cp_{labels[idx]}_new.dat'
    if os.path.exists(potential_skin_data_filename):

        x_validation_pot  = np.loadtxt(potential_skin_data_filename, usecols=(0,))
        cp_validation_pot = np.loadtxt(potential_skin_data_filename, usecols=(1,))
        plt.scatter(x_validation_pot, -cp_validation_pot, marker="*", label="Validation potential solver", s=10)

    if os.path.exists(potential_skin_data_filename_new):
        x_validation_pot_new  = np.loadtxt(potential_skin_data_filename_new, usecols=(0,))
        cp_validation_pot_new = np.loadtxt(potential_skin_data_filename_new, usecols=(1,))
        plt.scatter(x_validation_pot_new, cp_validation_pot_new, marker="*", label="Validation potential solver new", s=10)

    plt.title('Values')
    plt.ylabel('y')
    plt.xlabel('x')
    plt.grid(True)
    plt.legend()
    plt.show()